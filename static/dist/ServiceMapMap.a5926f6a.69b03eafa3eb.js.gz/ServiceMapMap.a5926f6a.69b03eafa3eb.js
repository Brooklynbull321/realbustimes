(() => {
  function e(e, t, o, r) {
    Object.defineProperty(e, t, {
      get: o,
      set: r,
      enumerable: !0,
      configurable: !0,
    });
  }
  function t(e) {
    return e && e.__esModule ? e.default : e;
  }
  var o = (
      "undefined" != typeof globalThis
        ? globalThis
        : "undefined" != typeof self
        ? self
        : "undefined" != typeof window
        ? window
        : "undefined" != typeof global
        ? global
        : {}
    ).parcelRequire94c2,
    r = o.register;
  r("7gRhS", function (t, r) {
    e(t.exports, "default", () => a),
      e(t.exports, "Marker", () => o("7S46k").Marker),
      e(t.exports, "Popup", () => o("bL6OX").Popup),
      e(t.exports, "AttributionControl", () => o("irbok").AttributionControl),
      e(t.exports, "GeolocateControl", () => o("2eNKd").GeolocateControl),
      e(t.exports, "NavigationControl", () => o("8PbLE").NavigationControl),
      e(t.exports, "Source", () => o("4wDNR").Source),
      e(t.exports, "Layer", () => o("4Z6et").Layer),
      e(t.exports, "useControl", () => o("8e4gr").useControl),
      e(t.exports, "useMap", () => o("1L5AA").useMap);
    var n = o("kcKPR");
    o("7S46k"),
      o("bL6OX"),
      o("irbok"),
      o("gk4FY"),
      o("2eNKd"),
      o("8PbLE"),
      o("b2P5B"),
      o("jMyVo"),
      o("9sB0Y"),
      o("4wDNR"),
      o("4Z6et"),
      o("8e4gr"),
      o("1L5AA"),
      o("epMju"),
      o("1eseT"),
      o("erkl2"),
      o("guwkA");
    var a = n.Map;
  }),
    r("kcKPR", function (t, r) {
      e(t.exports, "MapContext", () => c), e(t.exports, "Map", () => d);
      var n = o("gQnzB"),
        a = o("1L5AA"),
        i = o("aRtMf"),
        l = o("haW3W"),
        s = o("7tQji"),
        u = o("lPcIe");
      let c = n.createContext(null),
        d = n.forwardRef(function (e, t) {
          let r = (0, n.useContext)(a.MountedMapsContext),
            [d, p] = (0, n.useState)(null),
            f = (0, n.useRef)(),
            { current: h } = (0, n.useRef)({ mapLib: null, map: null });
          (0, n.useEffect)(() => {
            let t;
            let n = e.mapLib,
              a = !0;
            return (
              Promise.resolve(n || o("3H37u"))
                .then((o) => {
                  if (!a) return;
                  if (!o) throw Error("Invalid mapLib");
                  let n = "Map" in o ? o : o.default;
                  if (!n.Map) throw Error("Invalid mapLib");
                  if (((0, u.default)(n, e), !n.supported || n.supported(e)))
                    e.reuseMaps && (t = (0, i.default).reuse(e, f.current)),
                      t || (t = new i.default(n.Map, e, f.current)),
                      (h.map = (0, l.default)(t)),
                      (h.mapLib = n),
                      p(t),
                      null == r || r.onMapMount(h.map, e.id);
                  else throw Error("Map is not supported by this browser");
                })
                .catch((t) => {
                  let { onError: o } = e;
                  o
                    ? o({
                        type: "error",
                        target: null,
                        originalEvent: null,
                        error: t,
                      })
                    : console.error(t);
                }),
              () => {
                (a = !1),
                  t &&
                    (null == r || r.onMapUnmount(e.id),
                    e.reuseMaps ? t.recycle() : t.destroy());
              }
            );
          }, []),
            (0, s.default)(() => {
              d && d.setProps(e);
            }),
            (0, n.useImperativeHandle)(t, () => h.map, [d]);
          let m = (0, n.useMemo)(
            () => ({
              position: "relative",
              width: "100%",
              height: "100%",
              ...e.style,
            }),
            [e.style]
          );
          return n.createElement(
            "div",
            { id: e.id, ref: f, style: m },
            d &&
              n.createElement(
                c.Provider,
                { value: h },
                n.createElement(
                  "div",
                  { "mapboxgl-children": "", style: { height: "100%" } },
                  e.children
                )
              )
          );
        });
    }),
    r("1L5AA", function (t, r) {
      e(t.exports, "MountedMapsContext", () => i),
        e(t.exports, "useMap", () => l);
      var n = o("gQnzB"),
        a = o("kcKPR");
      let i = n.createContext(null);
      function l() {
        var e;
        let t =
            null === (e = (0, n.useContext)(i)) || void 0 === e
              ? void 0
              : e.maps,
          o = (0, n.useContext)(a.MapContext);
        return (0,
        n.useMemo)(() => ({ ...t, current: null == o ? void 0 : o.map }), [t, o]);
      }
    }),
    r("aRtMf", function (t, r) {
      e(t.exports, "default", () => h);
      var n = o("e8Xc2"),
        a = o("b5nhJ"),
        i = o("8T56L");
      let l = { version: 8, sources: {}, layers: [] },
        s = {
          mousedown: "onMouseDown",
          mouseup: "onMouseUp",
          mouseover: "onMouseOver",
          mousemove: "onMouseMove",
          click: "onClick",
          dblclick: "onDblClick",
          mouseenter: "onMouseEnter",
          mouseleave: "onMouseLeave",
          mouseout: "onMouseOut",
          contextmenu: "onContextMenu",
          touchstart: "onTouchStart",
          touchend: "onTouchEnd",
          touchmove: "onTouchMove",
          touchcancel: "onTouchCancel",
        },
        u = {
          movestart: "onMoveStart",
          move: "onMove",
          moveend: "onMoveEnd",
          dragstart: "onDragStart",
          drag: "onDrag",
          dragend: "onDragEnd",
          zoomstart: "onZoomStart",
          zoom: "onZoom",
          zoomend: "onZoomEnd",
          rotatestart: "onRotateStart",
          rotate: "onRotate",
          rotateend: "onRotateEnd",
          pitchstart: "onPitchStart",
          pitch: "onPitch",
          pitchend: "onPitchEnd",
        },
        c = {
          wheel: "onWheel",
          boxzoomstart: "onBoxZoomStart",
          boxzoomend: "onBoxZoomEnd",
          boxzoomcancel: "onBoxZoomCancel",
          resize: "onResize",
          load: "onLoad",
          render: "onRender",
          idle: "onIdle",
          remove: "onRemove",
          data: "onData",
          styledata: "onStyleData",
          sourcedata: "onSourceData",
          error: "onError",
        },
        d = [
          "minZoom",
          "maxZoom",
          "minPitch",
          "maxPitch",
          "maxBounds",
          "projection",
          "renderWorldCopies",
        ],
        p = [
          "scrollZoom",
          "boxZoom",
          "dragRotate",
          "dragPan",
          "keyboard",
          "doubleClickZoom",
          "touchZoomRotate",
          "touchPitch",
        ];
      class f {
        get map() {
          return this._map;
        }
        setProps(e) {
          let t = this.props;
          this.props = e;
          let o = this._updateSettings(e, t),
            r = this._updateSize(e),
            n = this._updateViewState(e);
          this._updateStyle(e, t),
            this._updateStyleComponents(e),
            this._updateHandlers(e, t),
            (o || r || (n && !this._map.isMoving())) && this.redraw();
        }
        static reuse(e, t) {
          let o = f.savedMaps.pop();
          if (!o) return null;
          let r = o.map,
            n = r.getContainer();
          for (t.className = n.className; n.childNodes.length > 0; )
            t.appendChild(n.childNodes[0]);
          r._container = t;
          let a = r._resizeObserver;
          a && (a.disconnect(), a.observe(t)),
            o.setProps({ ...e, styleDiffing: !1 }),
            r.resize();
          let { initialViewState: i } = e;
          return (
            i &&
              (i.bounds
                ? r.fitBounds(i.bounds, { ...i.fitBoundsOptions, duration: 0 })
                : o._updateViewState(i)),
            r.isStyleLoaded()
              ? r.fire("load")
              : r.once("style.load", () => r.fire("load")),
            r._update(),
            o
          );
        }
        _initialize(e) {
          let { props: t } = this,
            { mapStyle: o = l } = t,
            r = {
              ...t,
              ...t.initialViewState,
              container: e,
              style: (0, a.normalizeStyle)(o),
            },
            n = r.initialViewState || r.viewState || r;
          if (
            (Object.assign(r, {
              center: [n.longitude || 0, n.latitude || 0],
              zoom: n.zoom || 0,
              pitch: n.pitch || 0,
              bearing: n.bearing || 0,
            }),
            t.gl)
          ) {
            let e = HTMLCanvasElement.prototype.getContext;
            HTMLCanvasElement.prototype.getContext = () => (
              (HTMLCanvasElement.prototype.getContext = e), t.gl
            );
          }
          let i = new this._MapClass(r);
          for (let e in (n.padding && i.setPadding(n.padding),
          t.cursor && (i.getCanvas().style.cursor = t.cursor),
          (i.transformCameraUpdate = this._onCameraUpdate),
          i.on("style.load", () => {
            var e;
            (this._styleComponents = {
              light: i.getLight(),
              sky: i.getSky(),
              projection:
                null === (e = i.getProjection) || void 0 === e
                  ? void 0
                  : e.call(i),
              terrain: i.getTerrain(),
            }),
              this._updateStyleComponents(this.props);
          }),
          i.on("sourcedata", () => {
            this._updateStyleComponents(this.props);
          }),
          s))
            i.on(e, this._onPointerEvent);
          for (let e in u) i.on(e, this._onCameraEvent);
          for (let e in c) i.on(e, this._onEvent);
          this._map = i;
        }
        recycle() {
          let e = this.map.getContainer().querySelector("[mapboxgl-children]");
          null == e || e.remove(), f.savedMaps.push(this);
        }
        destroy() {
          this._map.remove();
        }
        redraw() {
          let e = this._map;
          e.style &&
            (e._frame && (e._frame.cancel(), (e._frame = null)), e._render());
        }
        _updateSize(e) {
          let { viewState: t } = e;
          if (t) {
            let e = this._map;
            if (
              t.width !== e.transform.width ||
              t.height !== e.transform.height
            )
              return e.resize(), !0;
          }
          return !1;
        }
        _updateViewState(e) {
          let t = this._map,
            o = t.transform;
          if (!t.isMoving()) {
            let r = (0, n.applyViewStateToTransform)(o, e);
            if (Object.keys(r).length > 0)
              return (
                (this._internalUpdate = !0),
                t.jumpTo(r),
                (this._internalUpdate = !1),
                !0
              );
          }
          return !1;
        }
        _updateSettings(e, t) {
          let o = this._map,
            r = !1;
          for (let n of d)
            if (n in e && !(0, i.deepEqual)(e[n], t[n])) {
              r = !0;
              let t = o[`set${n[0].toUpperCase()}${n.slice(1)}`];
              null == t || t.call(o, e[n]);
            }
          return r;
        }
        _updateStyle(e, t) {
          if (
            (e.cursor !== t.cursor &&
              (this._map.getCanvas().style.cursor = e.cursor || ""),
            e.mapStyle !== t.mapStyle)
          ) {
            let { mapStyle: t = l, styleDiffing: o = !0 } = e,
              r = { diff: o };
            "localIdeographFontFamily" in e &&
              (r.localIdeographFontFamily = e.localIdeographFontFamily),
              this._map.setStyle((0, a.normalizeStyle)(t), r);
          }
        }
        _updateStyleComponents({
          light: e,
          projection: t,
          sky: o,
          terrain: r,
        }) {
          let n = this._map,
            a = this._styleComponents;
          if (n.style._loaded) {
            var l, s;
            e &&
              !(0, i.deepEqual)(e, a.light) &&
              ((a.light = e), n.setLight(e)),
              t &&
                !(0, i.deepEqual)(t, a.projection) &&
                t !==
                  (null === (l = a.projection) || void 0 === l
                    ? void 0
                    : l.type) &&
                ((a.projection = "string" == typeof t ? { type: t } : t),
                null === (s = n.setProjection) ||
                  void 0 === s ||
                  s.call(n, a.projection)),
              o && !(0, i.deepEqual)(o, a.sky) && ((a.sky = o), n.setSky(o)),
              void 0 !== r &&
                !(0, i.deepEqual)(r, a.terrain) &&
                (!r || n.getSource(r.source)) &&
                ((a.terrain = r), n.setTerrain(r));
          }
        }
        _updateHandlers(e, t) {
          let o = this._map;
          for (let a of p) {
            var r, n;
            let l = null === (r = e[a]) || void 0 === r || r,
              s = null === (n = t[a]) || void 0 === n || n;
            (0, i.deepEqual)(l, s) || (l ? o[a].enable(l) : o[a].disable());
          }
        }
        _queryRenderedFeatures(e) {
          let t = this._map,
            { interactiveLayerIds: o = [] } = this.props;
          try {
            return t.queryRenderedFeatures(e, {
              layers: o.filter(t.getLayer.bind(t)),
            });
          } catch {
            return [];
          }
        }
        _updateHover(e) {
          let { props: t } = this;
          if (
            t.interactiveLayerIds &&
            (t.onMouseMove || t.onMouseEnter || t.onMouseLeave)
          ) {
            var o;
            let t = e.type,
              r =
                (null === (o = this._hoveredFeatures) || void 0 === o
                  ? void 0
                  : o.length) > 0,
              n = this._queryRenderedFeatures(e.point),
              a = n.length > 0;
            !a && r && ((e.type = "mouseleave"), this._onPointerEvent(e)),
              (this._hoveredFeatures = n),
              a && !r && ((e.type = "mouseenter"), this._onPointerEvent(e)),
              (e.type = t);
          } else this._hoveredFeatures = null;
        }
        constructor(e, t, o) {
          (this._map = null),
            (this._internalUpdate = !1),
            (this._hoveredFeatures = null),
            (this._propsedCameraUpdate = null),
            (this._styleComponents = {}),
            (this._onEvent = (e) => {
              let t = this.props[c[e.type]];
              t ? t(e) : "error" === e.type && console.error(e.error);
            }),
            (this._onCameraEvent = (e) => {
              if (this._internalUpdate) return;
              e.viewState =
                this._propsedCameraUpdate ||
                (0, n.transformToViewState)(this._map.transform);
              let t = this.props[u[e.type]];
              t && t(e);
            }),
            (this._onCameraUpdate = (e) =>
              this._internalUpdate
                ? e
                : ((this._propsedCameraUpdate = (0, n.transformToViewState)(e)),
                  (0, n.applyViewStateToTransform)(e, this.props))),
            (this._onPointerEvent = (e) => {
              ("mousemove" === e.type || "mouseout" === e.type) &&
                this._updateHover(e);
              let t = this.props[s[e.type]];
              t &&
                (this.props.interactiveLayerIds &&
                  "mouseover" !== e.type &&
                  "mouseout" !== e.type &&
                  (e.features =
                    this._hoveredFeatures ||
                    this._queryRenderedFeatures(e.point)),
                t(e),
                delete e.features);
            }),
            (this._MapClass = e),
            (this.props = t),
            this._initialize(o);
        }
      }
      f.savedMaps = [];
      var h = f;
    }),
    r("e8Xc2", function (t, r) {
      e(t.exports, "transformToViewState", () => a),
        e(t.exports, "applyViewStateToTransform", () => i);
      var n = o("8T56L");
      function a(e) {
        return {
          longitude: e.center.lng,
          latitude: e.center.lat,
          zoom: e.zoom,
          pitch: e.pitch,
          bearing: e.bearing,
          padding: e.padding,
        };
      }
      function i(e, t) {
        let o = t.viewState || t,
          r = {};
        return (
          "longitude" in o &&
            "latitude" in o &&
            (o.longitude !== e.center.lng || o.latitude !== e.center.lat) &&
            (r.center = new e.center.constructor(o.longitude, o.latitude)),
          "zoom" in o && o.zoom !== e.zoom && (r.zoom = o.zoom),
          "bearing" in o && o.bearing !== e.bearing && (r.bearing = o.bearing),
          "pitch" in o && o.pitch !== e.pitch && (r.pitch = o.pitch),
          o.padding &&
            e.padding &&
            !(0, n.deepEqual)(o.padding, e.padding) &&
            (r.padding = o.padding),
          r
        );
      }
    }),
    r("8T56L", function (t, o) {
      function r(e, t) {
        let o = Array.isArray(e) ? e[0] : e ? e.x : 0,
          r = Array.isArray(e) ? e[1] : e ? e.y : 0,
          n = Array.isArray(t) ? t[0] : t ? t.x : 0,
          a = Array.isArray(t) ? t[1] : t ? t.y : 0;
        return o === n && r === a;
      }
      e(t.exports, "arePointsEqual", () => r),
        e(
          t.exports,
          "deepEqual",
          () =>
            function e(t, o) {
              if (t === o) return !0;
              if (!t || !o) return !1;
              if (Array.isArray(t)) {
                if (!Array.isArray(o) || t.length !== o.length) return !1;
                for (let r = 0; r < t.length; r++)
                  if (!e(t[r], o[r])) return !1;
                return !0;
              }
              if (Array.isArray(o)) return !1;
              if ("object" == typeof t && "object" == typeof o) {
                let r = Object.keys(t),
                  n = Object.keys(o);
                if (r.length !== n.length) return !1;
                for (let n of r)
                  if (!o.hasOwnProperty(n) || !e(t[n], o[n])) return !1;
                return !0;
              }
              return !1;
            }
        );
    }),
    r("b5nhJ", function (t, o) {
      e(t.exports, "normalizeStyle", () => n);
      let r = [
        "type",
        "source",
        "source-layer",
        "minzoom",
        "maxzoom",
        "filter",
        "layout",
      ];
      function n(e) {
        if (!e) return null;
        if ("string" == typeof e || ("toJS" in e && (e = e.toJS()), !e.layers))
          return e;
        let t = {};
        for (let o of e.layers) t[o.id] = o;
        let o = e.layers.map((e) => {
          let o = null;
          "interactive" in e &&
            ((o = Object.assign({}, e)), delete o.interactive);
          let n = t[e.ref];
          if (n)
            for (let t of ((o = o || Object.assign({}, e)), delete o.ref, r))
              t in n && (o[t] = n[t]);
          return o || e;
        });
        return { ...e, layers: o };
      }
    }),
    r("haW3W", function (t, o) {
      e(t.exports, "default", () => n);
      let r = [
        "setMaxBounds",
        "setMinZoom",
        "setMaxZoom",
        "setMinPitch",
        "setMaxPitch",
        "setRenderWorldCopies",
        "setProjection",
        "setStyle",
        "addSource",
        "removeSource",
        "addLayer",
        "removeLayer",
        "setLayerZoomRange",
        "setFilter",
        "setPaintProperty",
        "setLayoutProperty",
        "setLight",
        "setTerrain",
        "setFog",
        "remove",
      ];
      function n(e) {
        if (!e) return null;
        let t = e.map,
          o = { getMap: () => t };
        for (let e of (function (e) {
          let t = new Set(),
            o = e;
          for (; o; ) {
            for (let r of Object.getOwnPropertyNames(o))
              "_" !== r[0] &&
                "function" == typeof e[r] &&
                "fire" !== r &&
                "setEventedParent" !== r &&
                t.add(r);
            o = Object.getPrototypeOf(o);
          }
          return Array.from(t);
        })(t))
          e in o || r.includes(e) || (o[e] = t[e].bind(t));
        return o;
      }
    }),
    r("7tQji", function (t, r) {
      e(t.exports, "default", () => a);
      var n = o("gQnzB"),
        a = "undefined" != typeof document ? n.useLayoutEffect : n.useEffect;
    }),
    r("lPcIe", function (t, o) {
      e(t.exports, "default", () => r);
      function r(e, t) {
        let {
          RTLTextPlugin: o,
          maxParallelImageRequests: r,
          workerCount: n,
          workerUrl: a,
        } = t;
        if (
          o &&
          e.getRTLTextPluginStatus &&
          "unavailable" === e.getRTLTextPluginStatus()
        ) {
          let { pluginUrl: t, lazy: r = !0 } =
            "string" == typeof o ? { pluginUrl: o } : o;
          e.setRTLTextPlugin(
            t,
            (e) => {
              e && console.error(e);
            },
            r
          );
        }
        void 0 !== r && e.setMaxParallelImageRequests(r),
          void 0 !== n && e.setWorkerCount(n),
          void 0 !== a && e.setWorkerUrl(a);
      }
    }),
    r("3H37u", function (e, t) {
      e.exports = o("9xcZT")(o("isgaU").resolve("1fRws")).then(() =>
        o("fJgVi")
      );
    }),
    r("9xcZT", function (e, t) {
      e.exports = o("4l3Ee")(function (e) {
        return new Promise(function (t, o) {
          if (
            []
              .concat(document.getElementsByTagName("script"))
              .some(function (t) {
                return t.src === e;
              })
          ) {
            t();
            return;
          }
          var r = document.createElement("link");
          (r.href = e),
            (r.rel = "preload"),
            (r.as = "script"),
            document.head.appendChild(r);
          var n = document.createElement("script");
          (n.async = !0),
            (n.type = "text/javascript"),
            (n.src = e),
            (n.onerror = function (t) {
              var r = TypeError(
                "Failed to fetch dynamically imported module: "
                  .concat(e, ". Error: ")
                  .concat(t.message)
              );
              (n.onerror = n.onload = null), n.remove(), o(r);
            }),
            (n.onload = function () {
              (n.onerror = n.onload = null), t();
            }),
            document.getElementsByTagName("head")[0].appendChild(n);
        });
      });
    }),
    r("4l3Ee", function (e, t) {
      var o = {},
        r = {},
        n = {};
      e.exports = function (e, t) {
        return function (a) {
          var i = (function (e) {
            switch (e) {
              case "preload":
                return r;
              case "prefetch":
                return n;
              default:
                return o;
            }
          })(t);
          return i[a]
            ? i[a]
            : (i[a] = e.apply(null, arguments).catch(function (e) {
                throw (delete i[a], e);
              }));
        };
      };
    }),
    r("isgaU", function (t, o) {
      e(
        t.exports,
        "register",
        () => r,
        (e) => (r = e)
      ),
        e(
          t.exports,
          "resolve",
          () => n,
          (e) => (n = e)
        );
      var r,
        n,
        a = new Map();
      (r = function (e, t) {
        for (var o = 0; o < t.length - 1; o += 2)
          a.set(t[o], { baseUrl: e, path: t[o + 1] });
      }),
        (n = function (e) {
          var t = a.get(e);
          if (null == t) throw Error("Could not resolve bundle with id " + e);
          return new URL(t.path, t.baseUrl).toString();
        });
    }),
    r("7S46k", function (t, r) {
      e(t.exports, "Marker", () => u);
      var n = o("gQnzB"),
        a = o("bLNSt"),
        i = o("SoTjU"),
        l = o("kcKPR"),
        s = o("8T56L");
      let u = (0, n.memo)(
        (0, n.forwardRef)((e, t) => {
          let { map: o, mapLib: r } = (0, n.useContext)(l.MapContext),
            u = (0, n.useRef)({ props: e });
          u.current.props = e;
          let c = (0, n.useMemo)(() => {
            let t = !1;
            n.Children.forEach(e.children, (e) => {
              e && (t = !0);
            });
            let o = { ...e, element: t ? document.createElement("div") : null },
              a = new r.Marker(o);
            return (
              a.setLngLat([e.longitude, e.latitude]),
              a.getElement().addEventListener("click", (e) => {
                var t, o;
                null === (t = (o = u.current.props).onClick) ||
                  void 0 === t ||
                  t.call(o, { type: "click", target: a, originalEvent: e });
              }),
              a.on("dragstart", (e) => {
                var t, o;
                (e.lngLat = c.getLngLat()),
                  null === (t = (o = u.current.props).onDragStart) ||
                    void 0 === t ||
                    t.call(o, e);
              }),
              a.on("drag", (e) => {
                var t, o;
                (e.lngLat = c.getLngLat()),
                  null === (t = (o = u.current.props).onDrag) ||
                    void 0 === t ||
                    t.call(o, e);
              }),
              a.on("dragend", (e) => {
                var t, o;
                (e.lngLat = c.getLngLat()),
                  null === (t = (o = u.current.props).onDragEnd) ||
                    void 0 === t ||
                    t.call(o, e);
              }),
              a
            );
          }, []);
          (0, n.useEffect)(
            () => (
              c.addTo(o.getMap()),
              () => {
                c.remove();
              }
            ),
            []
          );
          let {
            longitude: d,
            latitude: p,
            offset: f,
            style: h,
            draggable: m = !1,
            popup: g = null,
            rotation: v = 0,
            rotationAlignment: y = "auto",
            pitchAlignment: A = "auto",
          } = e;
          return (
            (0, n.useEffect)(() => {
              (0, i.applyReactStyle)(c.getElement(), h);
            }, [h]),
            (0, n.useImperativeHandle)(t, () => c, []),
            (c.getLngLat().lng !== d || c.getLngLat().lat !== p) &&
              c.setLngLat([d, p]),
            f && !(0, s.arePointsEqual)(c.getOffset(), f) && c.setOffset(f),
            c.isDraggable() !== m && c.setDraggable(m),
            c.getRotation() !== v && c.setRotation(v),
            c.getRotationAlignment() !== y && c.setRotationAlignment(y),
            c.getPitchAlignment() !== A && c.setPitchAlignment(A),
            c.getPopup() !== g && c.setPopup(g),
            (0, a.createPortal)(e.children, c.getElement())
          );
        })
      );
    }),
    r("SoTjU", function (t, o) {
      e(t.exports, "applyReactStyle", () => n);
      let r =
        /box|flex|grid|column|lineHeight|fontWeight|opacity|order|tabSize|zIndex/;
      function n(e, t) {
        if (!e || !t) return;
        let o = e.style;
        for (let e in t) {
          let n = t[e];
          Number.isFinite(n) && !r.test(e) ? (o[e] = `${n}px`) : (o[e] = n);
        }
      }
    }),
    r("bL6OX", function (t, r) {
      e(t.exports, "Popup", () => c);
      var n = o("bLNSt"),
        a = o("gQnzB"),
        i = o("SoTjU"),
        l = o("kcKPR"),
        s = o("8T56L");
      function u(e) {
        return new Set(e ? e.trim().split(/\s+/) : []);
      }
      let c = (0, a.memo)(
        (0, a.forwardRef)((e, t) => {
          let { map: o, mapLib: r } = (0, a.useContext)(l.MapContext),
            c = (0, a.useMemo)(() => document.createElement("div"), []),
            d = (0, a.useRef)({ props: e });
          d.current.props = e;
          let p = (0, a.useMemo)(() => {
            let t = { ...e },
              o = new r.Popup(t);
            return (
              o.setLngLat([e.longitude, e.latitude]),
              o.once("open", (e) => {
                var t, o;
                null === (t = (o = d.current.props).onOpen) ||
                  void 0 === t ||
                  t.call(o, e);
              }),
              o
            );
          }, []);
          if (
            ((0, a.useEffect)(() => {
              let e = (e) => {
                var t, o;
                null === (t = (o = d.current.props).onClose) ||
                  void 0 === t ||
                  t.call(o, e);
              };
              return (
                p.on("close", e),
                p.setDOMContent(c).addTo(o.getMap()),
                () => {
                  p.off("close", e), p.isOpen() && p.remove();
                }
              );
            }, []),
            (0, a.useEffect)(() => {
              (0, i.applyReactStyle)(p.getElement(), e.style);
            }, [e.style]),
            (0, a.useImperativeHandle)(t, () => p, []),
            p.isOpen() &&
              ((p.getLngLat().lng !== e.longitude ||
                p.getLngLat().lat !== e.latitude) &&
                p.setLngLat([e.longitude, e.latitude]),
              e.offset &&
                !(0, s.deepEqual)(p.options.offset, e.offset) &&
                p.setOffset(e.offset),
              (p.options.anchor !== e.anchor ||
                p.options.maxWidth !== e.maxWidth) &&
                ((p.options.anchor = e.anchor), p.setMaxWidth(e.maxWidth)),
              p.options.className !== e.className))
          ) {
            let t = u(p.options.className),
              o = u(e.className);
            for (let e of t) o.has(e) || p.removeClassName(e);
            for (let e of o) t.has(e) || p.addClassName(e);
            p.options.className = e.className;
          }
          return (0, n.createPortal)(e.children, c);
        })
      );
    }),
    r("irbok", function (t, r) {
      e(t.exports, "AttributionControl", () => l);
      var n = o("gQnzB"),
        a = o("SoTjU"),
        i = o("8e4gr");
      let l = (0, n.memo)(function (e) {
        let t = (0, i.useControl)(
          ({ mapLib: t }) => new t.AttributionControl(e),
          { position: e.position }
        );
        return (
          (0, n.useEffect)(() => {
            (0, a.applyReactStyle)(t._container, e.style);
          }, [e.style]),
          null
        );
      });
    }),
    r("8e4gr", function (t, r) {
      e(t.exports, "useControl", () => i);
      var n = o("gQnzB"),
        a = o("kcKPR");
      function i(e, t, o, r) {
        let i = (0, n.useContext)(a.MapContext),
          l = (0, n.useMemo)(() => e(i), []);
        return (
          (0, n.useEffect)(() => {
            let e = r || o || t,
              n = "function" == typeof t && "function" == typeof o ? t : null,
              a =
                "function" == typeof o ? o : "function" == typeof t ? t : null,
              { map: s } = i;
            return (
              !s.hasControl(l) &&
                (s.addControl(l, null == e ? void 0 : e.position), n && n(i)),
              () => {
                a && a(i), s.hasControl(l) && s.removeControl(l);
              }
            );
          }, []),
          l
        );
      }
    }),
    r("gk4FY", function (e, t) {
      var r = o("gQnzB"),
        n = o("SoTjU"),
        a = o("8e4gr");
      (0, r.memo)(function (e) {
        let t = (0, a.useControl)(
          ({ mapLib: t }) =>
            new t.FullscreenControl({
              container:
                e.containerId && document.getElementById(e.containerId),
            }),
          { position: e.position }
        );
        return (
          (0, r.useEffect)(() => {
            (0, n.applyReactStyle)(t._controlContainer, e.style);
          }, [e.style]),
          null
        );
      });
    }),
    r("2eNKd", function (t, r) {
      e(t.exports, "GeolocateControl", () => l);
      var n = o("gQnzB"),
        a = o("SoTjU"),
        i = o("8e4gr");
      let l = (0, n.memo)(
        (0, n.forwardRef)(function (e, t) {
          let o = (0, n.useRef)({ props: e }),
            r = (0, i.useControl)(
              ({ mapLib: t }) => {
                let r = new t.GeolocateControl(e),
                  n = r._setupUI;
                return (
                  (r._setupUI = () => {
                    r._container.hasChildNodes() || n();
                  }),
                  r.on("geolocate", (e) => {
                    var t, r;
                    null === (t = (r = o.current.props).onGeolocate) ||
                      void 0 === t ||
                      t.call(r, e);
                  }),
                  r.on("error", (e) => {
                    var t, r;
                    null === (t = (r = o.current.props).onError) ||
                      void 0 === t ||
                      t.call(r, e);
                  }),
                  r.on("outofmaxbounds", (e) => {
                    var t, r;
                    null === (t = (r = o.current.props).onOutOfMaxBounds) ||
                      void 0 === t ||
                      t.call(r, e);
                  }),
                  r.on("trackuserlocationstart", (e) => {
                    var t, r;
                    null ===
                      (t = (r = o.current.props).onTrackUserLocationStart) ||
                      void 0 === t ||
                      t.call(r, e);
                  }),
                  r.on("trackuserlocationend", (e) => {
                    var t, r;
                    null ===
                      (t = (r = o.current.props).onTrackUserLocationEnd) ||
                      void 0 === t ||
                      t.call(r, e);
                  }),
                  r
                );
              },
              { position: e.position }
            );
          return (
            (o.current.props = e),
            (0, n.useImperativeHandle)(t, () => r, []),
            (0, n.useEffect)(() => {
              (0, a.applyReactStyle)(r._container, e.style);
            }, [e.style]),
            null
          );
        })
      );
    }),
    r("8PbLE", function (t, r) {
      e(t.exports, "NavigationControl", () => l);
      var n = o("gQnzB"),
        a = o("SoTjU"),
        i = o("8e4gr");
      let l = (0, n.memo)(function (e) {
        let t = (0, i.useControl)(
          ({ mapLib: t }) => new t.NavigationControl(e),
          { position: e.position }
        );
        return (
          (0, n.useEffect)(() => {
            (0, a.applyReactStyle)(t._container, e.style);
          }, [e.style]),
          null
        );
      });
    }),
    r("b2P5B", function (e, t) {
      var r = o("gQnzB"),
        n = o("SoTjU"),
        a = o("8e4gr");
      (0, r.memo)(function (e) {
        let t = (0, a.useControl)(({ mapLib: t }) => new t.ScaleControl(e), {
            position: e.position,
          }),
          o = (0, r.useRef)(e),
          i = o.current;
        o.current = e;
        let { style: l } = e;
        return (
          void 0 !== e.maxWidth &&
            e.maxWidth !== i.maxWidth &&
            (t.options.maxWidth = e.maxWidth),
          void 0 !== e.unit && e.unit !== i.unit && t.setUnit(e.unit),
          (0, r.useEffect)(() => {
            (0, n.applyReactStyle)(t._container, l);
          }, [l]),
          null
        );
      });
    }),
    r("jMyVo", function (e, t) {
      var r = o("gQnzB"),
        n = o("SoTjU"),
        a = o("8e4gr");
      (0, r.memo)(function (e) {
        let t = (0, a.useControl)(({ mapLib: t }) => new t.TerrainControl(e), {
          position: e.position,
        });
        return (
          (0, r.useEffect)(() => {
            (0, n.applyReactStyle)(t._container, e.style);
          }, [e.style]),
          null
        );
      });
    }),
    r("9sB0Y", function (e, t) {
      var r = o("gQnzB"),
        n = o("SoTjU"),
        a = o("8e4gr");
      (0, r.memo)(function (e) {
        let t = (0, a.useControl)(({ mapLib: t }) => new t.LogoControl(e), {
          position: e.position,
        });
        return (
          (0, r.useEffect)(() => {
            (0, n.applyReactStyle)(t._container, e.style);
          }, [e.style]),
          null
        );
      });
    }),
    r("4wDNR", function (t, r) {
      e(t.exports, "Source", () => u);
      var n = o("gQnzB"),
        a = o("kcKPR"),
        i = o("1OKXu"),
        l = o("8T56L");
      let s = 0;
      function u(e) {
        let t = (0, n.useContext)(a.MapContext).map.getMap(),
          o = (0, n.useRef)(e),
          [, r] = (0, n.useState)(0),
          u = (0, n.useMemo)(() => e.id || `jsx-source-${s++}`, []);
        (0, n.useEffect)(() => {
          if (t) {
            let e = () => setTimeout(() => r((e) => e + 1), 0);
            return (
              t.on("styledata", e),
              e(),
              () => {
                if (
                  (t.off("styledata", e),
                  t.style && t.style._loaded && t.getSource(u))
                ) {
                  var o;
                  let e =
                    null === (o = t.getStyle()) || void 0 === o
                      ? void 0
                      : o.layers;
                  if (e) for (let o of e) o.source === u && t.removeLayer(o.id);
                  t.removeSource(u);
                }
              }
            );
          }
        }, [t]);
        let c = t && t.style && t.getSource(u);
        return (
          c
            ? (function (e, t, o) {
                var r, n, a;
                (0, i.default)(t.id === o.id, "source id changed"),
                  (0, i.default)(t.type === o.type, "source type changed");
                let s = "",
                  u = 0;
                for (let e in t)
                  "children" !== e &&
                    "id" !== e &&
                    !(0, l.deepEqual)(o[e], t[e]) &&
                    ((s = e), u++);
                if (!u) return;
                let c = t.type;
                if ("geojson" === c) e.setData(t.data);
                else if ("image" === c)
                  e.updateImage({ url: t.url, coordinates: t.coordinates });
                else
                  switch (s) {
                    case "coordinates":
                      null === (r = e.setCoordinates) ||
                        void 0 === r ||
                        r.call(e, t.coordinates);
                      break;
                    case "url":
                      null === (n = e.setUrl) ||
                        void 0 === n ||
                        n.call(e, t.url);
                      break;
                    case "tiles":
                      null === (a = e.setTiles) ||
                        void 0 === a ||
                        a.call(e, t.tiles);
                      break;
                    default:
                      console.warn(`Unable to update <Source> prop: ${s}`);
                  }
              })(c, e, o.current)
            : (c = (function (e, t, o) {
                if (e.style && e.style._loaded) {
                  let r = { ...o };
                  return (
                    delete r.id,
                    delete r.children,
                    e.addSource(t, r),
                    e.getSource(t)
                  );
                }
                return null;
              })(t, u, e)),
          (o.current = e),
          (c &&
            n.Children.map(
              e.children,
              (e) => e && (0, n.cloneElement)(e, { source: u })
            )) ||
            null
        );
      }
    }),
    r("1OKXu", function (t, o) {
      e(t.exports, "default", () => r);
      function r(e, t) {
        if (!e) throw Error(t);
      }
    }),
    r("4Z6et", function (t, r) {
      e(t.exports, "Layer", () => u);
      var n = o("gQnzB"),
        a = o("kcKPR"),
        i = o("1OKXu"),
        l = o("8T56L");
      let s = 0;
      function u(e) {
        let t = (0, n.useContext)(a.MapContext).map.getMap(),
          o = (0, n.useRef)(e),
          [, r] = (0, n.useState)(0),
          u = (0, n.useMemo)(() => e.id || `jsx-layer-${s++}`, []);
        if (
          ((0, n.useEffect)(() => {
            if (t) {
              let e = () => r((e) => e + 1);
              return (
                t.on("styledata", e),
                e(),
                () => {
                  t.off("styledata", e),
                    t.style &&
                      t.style._loaded &&
                      t.getLayer(u) &&
                      t.removeLayer(u);
                }
              );
            }
          }, [t]),
          t && t.style && t.getLayer(u))
        )
          try {
            !(function (e, t, o, r) {
              if (
                ((0, i.default)(o.id === r.id, "layer id changed"),
                (0, i.default)(o.type === r.type, "layer type changed"),
                "custom" === o.type || "custom" === r.type)
              )
                return;
              let {
                layout: n = {},
                paint: a = {},
                filter: s,
                minzoom: u,
                maxzoom: c,
                beforeId: d,
              } = o;
              if ((d !== r.beforeId && e.moveLayer(t, d), n !== r.layout)) {
                let o = r.layout || {};
                for (let r in n)
                  (0, l.deepEqual)(n[r], o[r]) ||
                    e.setLayoutProperty(t, r, n[r]);
                for (let r in o)
                  n.hasOwnProperty(r) || e.setLayoutProperty(t, r, void 0);
              }
              if (a !== r.paint) {
                let o = r.paint || {};
                for (let r in a)
                  (0, l.deepEqual)(a[r], o[r]) ||
                    e.setPaintProperty(t, r, a[r]);
                for (let r in o)
                  a.hasOwnProperty(r) || e.setPaintProperty(t, r, void 0);
              }
              (0, l.deepEqual)(s, r.filter) || e.setFilter(t, s),
                (u !== r.minzoom || c !== r.maxzoom) &&
                  e.setLayerZoomRange(t, u, c);
            })(t, u, e, o.current);
          } catch (e) {
            console.warn(e);
          }
        else
          !(function (e, t, o) {
            if (
              e.style &&
              e.style._loaded &&
              (!("source" in o) || e.getSource(o.source))
            ) {
              let r = { ...o, id: t };
              delete r.beforeId, e.addLayer(r, o.beforeId);
            }
          })(t, u, e);
        return (o.current = e), null;
      }
    }),
    r("epMju", function (e, t) {}),
    r("1eseT", function (e, t) {}),
    r("erkl2", function (e, t) {}),
    r("guwkA", function (e, t) {}),
    r("3IYRI", function (r, n) {
      e(r.exports, "ThemeContext", () => w), e(r.exports, "default", () => L);
      var a = o("bfktz"),
        i = o("gQnzB"),
        l = o("lQIRS");
      o("7gRhS");
      var s = o("irbok"),
        u = o("7gRhS"),
        c = o("2eNKd"),
        d = o("8PbLE"),
        p = o("bL6OX"),
        f = o("8e4gr"),
        h = o("1L5AA"),
        m = o("gv1uv"),
        g = o("i40lh"),
        v = o("963EK"),
        y = o("hgnA3"),
        A = o("cCR1g"),
        x = o("6H4u7");
      let C = {
          "stop-marker": t(o("d19JS")),
          "stop-marker-circle": t(x),
          "route-stop-marker": t(A),
          "route-stop-marker-circle": t(g),
          "route-stop-marker-dark": t(y),
          "route-stop-marker-dark-circle": t(v),
          arrow: t(m),
        },
        E = {
          alidade_smooth: "Light",
          alidade_smooth_dark: "Dark",
          alidade_36_dark: "36",
          alidade_satellite: "Satellite",
          osm_bright: "Bright",
        };
      class S {
        onAdd() {
          return (
            (this._container = document.createElement("div")),
            (0, l.createRoot)(this._container).render(
              (0, a.jsxs)("details", {
                className:
                  "maplibregl-ctrl maplibregl-ctrl-group map-style-switcher",
                children: [
                  (0, a.jsx)("summary", { children: "Map style" }),
                  Object.entries(E).map(([e, t]) =>
                    (0, a.jsxs)(
                      "label",
                      {
                        children: [
                          (0, a.jsx)("input", {
                            type: "radio",
                            value: e,
                            name: "map-style",
                            defaultChecked: e === this.style,
                            onChange: this.handleChange,
                          }),
                          t,
                        ],
                      },
                      e
                    )
                  ),
                ],
              })
            ),
            this._container
          );
        }
        onRemove() {
          var e, t;
          null === (t = this._container) ||
            void 0 === t ||
            null === (e = t.parentNode) ||
            void 0 === e ||
            e.removeChild(this._container);
        }
        constructor(e) {
          (this.style = e.style), (this.handleChange = e.onChange);
        }
      }
      let b = (0, i.memo)(function (e) {
          return (0, f.useControl)(() => new S(e)), null;
        }),
        w = (0, i.createContext)("");
      function B({ onInit: e }) {
        let { current: t } = (0, h.useMap)();
        return (
          (0, i.useEffect)(() => {
            if (t) {
              let o = t.getMap();
              o.keyboard.disableRotation(),
                o.touchZoomRotate.disableRotation(),
                e && e(o);
              let r = (e) => {
                if (e.id in C) {
                  let o = new Image();
                  (o.src = C[e.id]),
                    (o.onload = () => {
                      t.hasImage(e.id) ||
                        t.addImage(e.id, o, { pixelRatio: 2 });
                    });
                }
              };
              return (
                t.on("styleimagemissing", r),
                () => {
                  t.off("styleimagemissing", r);
                }
              );
            }
          }),
          null
        );
      }
      function L(e) {
        let o = window.matchMedia("(prefers-color-scheme: dark)"),
          [r, n] = t(i).useState(() => {
            try {
              let e = localStorage.getItem("map-style");
              if (e && e in E) return e;
            } catch {}
            return o.matches ? "alidade_smooth_dark" : "alidade_smooth";
          });
        (0, i.useEffect)(() => {
          let e = (e) => {
            n(e.matches ? "alidade_smooth_dark" : "alidade_smooth");
          };
          if (o.addEventListener)
            return (
              o.addEventListener("change", e),
              () => {
                o.removeEventListener("change", e);
              }
            );
        }, [o]);
        let l = t(i).useCallback(
            (e) => {
              let t = e.target.value,
                r = o.matches ? "alidade_smooth_dark" : "alidade_smooth";
              n(t);
              try {
                t === r
                  ? localStorage.removeItem("map-style")
                  : localStorage.setItem("map-style", t);
              } catch {}
            },
            [o.matches]
          ),
          [f, h] = t(i).useState(),
          m = (e) => {
            "lngLat" in e ? h(e.lngLat) : h(void 0);
          };
        return (
          (0, i.useEffect)(() => {
            document.body.classList.toggle("dark-mode", r.endsWith("_dark"));
          }, [r]),
          (0, a.jsx)(w.Provider, {
            value: r,
            children: (0, a.jsxs)(u.default, {
              ...e,
              reuseMaps: !0,
              touchPitch: !1,
              pitchWithRotate: !1,
              dragRotate: !1,
              minZoom: 2,
              maxZoom: 18,
              mapStyle: `https://tiles.stadiamaps.com/styles/${r}.json`,
              RTLTextPlugin: "",
              attributionControl: !1,
              onContextMenu: m,
              children: [
                (0, a.jsx)(d.NavigationControl, { showCompass: !1 }),
                (0, a.jsx)(c.GeolocateControl, { trackUserLocation: !0 }),
                (0, a.jsx)(b, { style: r, onChange: l }),
                (0, a.jsx)(s.AttributionControl, {}),
                (0, a.jsx)(B, { onInit: e.onMapInit }),
                e.children,
                f
                  ? (0, a.jsxs)(p.Popup, {
                      longitude: f.lng,
                      latitude: f.lat,
                      onClose: m,
                      children: [
                        (0, a.jsx)("a", {
                          href: `https://www.openstreetmap.org/#map=15/${f.lat}/${f.lng}`,
                          rel: "noopener noreferrer",
                          children: "OpenStreetMap",
                        }),
                        (0, a.jsx)("a", {
                          href: `https://www.google.com/maps/search/?api=1&query=${f.lat},${f.lng}`,
                          rel: "noopener noreferrer",
                          children: "Google Maps",
                        }),
                      ],
                    })
                  : null,
              ],
            }),
          })
        );
      }
    }),
    r("gv1uv", function (e, t) {
      e.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAQAAAAngNWGAAAAK0lEQVR42u3KMQHAMBDEMPEn7UL42xt7FZ0DWmm6m2GRqhw9%2BCdoh2bIDT9OrsU7sJz4AQAAAABJRU5ErkJggg%3D%3D";
    }),
    r("i40lh", function (e, t) {
      e.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAQAAABuvaSwAAAA%2BElEQVR42pVTMRZDQBBVpM5N5BBxEnkyU4SGC1CpFYo4jgNQCbq4QTRSeM%2BGx1prCf403s4378%2BfGYmHfQIZVfTBu9%2B0i32S1mCcMYAKyCQqDIzzAhUVKNq0GAUqc6rD0mKgw1XlkqUVmxGUHF0ZtTIBjyxNGtKhIWnyyJiYQTsG9MkN65pMUNduONYOerMqWpVRGX2sXrVGahf6b5oQEe3rKEWW7jfaVkOW0BDaKqoSeP2nGZEVWPFA9g%2BRmYzPtoxJg%2Flrq8HOuu8%2F6%2FScWXdgKBvj1vPpuFcXyYr5RdKuu1cU7L3L%2F9auO88KnsJZiQfbhgry%2FGB%2FYbk7Qn%2BieIQAAAAASUVORK5CYII%3D";
    }),
    r("963EK", function (e, t) {
      e.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAQAAABuvaSwAAAAtklEQVR42pWTrQ3GIBCG67oLC%2BDxuBrmQHcKVsCwQOeo4DCYjlF3H%2FnKT0tAHG9CCHlCHuBu6Qcwr0CDTjNb5uNYExQDtkAEfawDFDhcDWuBC3iPbuEOOMkN2%2BfUhp7o0KQ4PN84r65NwKJEkSPRvmSyO%2BiytaPosjdcP3Asp4pBbIHj%2F12LqxzCsroDW7x6lg7FJC7DXlVjM4VNtSbBJA3SBQlPR%2FoU0ncTColQorTip7cVqWF%2FEjVLG%2BSDKzcAAAAASUVORK5CYII%3D";
    }),
    r("hgnA3", function (e, t) {
      e.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAQAAABuvaSwAAAA2ElEQVR42o2TsQ2DMBBF6ZglLEAbZQCqNDCGXSdigHSewYXLNMyBBJ%2FGDWPQXUCWY8sWNv81h%2FWK43wupjt6xPC5RVWEQb%2FQGdBgQ5mVHVhR52XHhmcgf%2BnjIUjR6Ou1L%2B%2FCI6Ah6TUzlIEc83Y6i%2BQYaWV9QW7%2BvaOK5Bhl5e6CLKzMC3BTiktyZ0qVbWNuC1SmHKnJ%2FOB0O%2BahzYfMje4ImB38K30pR4YSqz2S1JxftwnqZbPHIykSJ4tk9afRkyvqghpravldbO8MOvGs4qBCB77TxQ%2F2By4KcudBWjRoAAAAAElFTkSuQmCC";
    }),
    r("cCR1g", function (e, t) {
      e.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAQAAABuvaSwAAABA0lEQVR42o2TMQ6CMBSGOzBzEzyEXMMFg%2B%2BZKIscwDo5OzjIcUxcZVJgE08gCw4kVBJo8VG1%2Fv8C6deX%2F%2FW1DCdw%2BODdbOqPuMWomgXx1SVGgW2AiXN0CWwybgbw%2FL4%2B9V6doSC4S%2BD1SRDVIrks0j5MYFNYU1VtjxLHSIN1XFUvuWWARRNGRXGMcC1kq%2BhpsK4w7uA9g137uTr%2FAc%2BmXaJHbY7hj2QD2dXYILfg2f4s0qrSj26ZvR0dYxjJvdsjwbWhNApsyEHI6smlVuNeZmTcrdAlt6wI4zCmF8kfs164AfHDnFGhq8JQ32RVosDGCEoClnBQWXVxCxz0cN%2FYA2f4YF%2Fr9GB6ifRHngAAAABJRU5ErkJggg%3D%3D";
    }),
    r("6H4u7", function (e, t) {
      e.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAQAAADZc7J%2FAAAB00lEQVR42qWVsU7bUBSGT6YUijJVDOlEVlh4hNYsdCELrJV4gLxDpHSAude%2Bt7vJS1goiQdERpRONFJdqamChFVE5BBL0ddaahVBgkns%2F5%2FPf3Xuvec7skgU2UfT5pqIO8455YgKBVlGlDHcs0ghDqX04jUaRAAPPf%2Bs5lhqU2%2Fbde03bzvTIQABVtrZXYCht2eLmXdVja8AUGzIvNhlAHFwrMQ856JpuUyAPrtPyzfow%2Biy4ohJ94F66AEDyo8DVNL3uhbzstf16BLosjYrt4DJgRKznCtOHACN%2F%2BUlAmi5Ypb3sQKif23gwPiqaGQlDz3AiAgFQqgqMat5zwbuKQoVmA7FrO7kNdgXjuC2kyXAPwO0cAp%2BM0tAzQHawjnUdZYASwHXwh1s21kCNjUQCRG8cfIEfIN3Kk8LHag5eS5Rg%2B%2FmecYPMO7l%2BUivGIGV%2FSuL8AV%2BeZJ1mER4SwQf7czjLMIniIOKswJQfgANmeGcbkLEzEhL2mCQUPFlrFXV5Cvwk%2FI81vtA3HKLKVhvu8QzrM%2BjXUGCt6pKXSyfeS3PCYsAYHoT%2BhfNut6xd%2By6vmiG%2FvQGgO%2B8l3RRwiHMtFxnosAWh5zg8fuvPU44ZGvxev8DxBIggNwqL4cAAAAASUVORK5CYII%3D";
    }),
    r("d19JS", function (e, t) {
      e.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAQAAADZc7J%2FAAABdElEQVR42qWVPUtCURiAT0sfJk616GRjuPgT0pYaxMXW6Af4IxIbbO7ce203%2F4Qkagg6ik0lZJChkBTGzQ%2Fk6SKEIH7kOc%2BzP3DvOed9Bav44p5rzjhgQ8yD%2F9PFxDM3INKLPTQurYfsR3HcBqBJeM3A1Ki0awBI3CoBx810PsMAaBBUCUyMyH4daOFVCzi6rF4FqLKjFnD0m6MmkFQNOF5IwMarGnBs54C0RuDYAHpsqQYcJ6dxohEo3QGWRiBuAgWNQEgCTxqBfQuwBTbsmTqBZziSOp9QhLip8xMtKGZ0jvEUfuo6F2mbbwhJ5assBLfwnlN9TA74sOHcUHvOE7iCUdNvrjFQXoGk%2BIMdqtCruKw1R9oUfLSgX4%2FI1cN98Ai84Z3dD0EawDCf2Vwy1gsZhtOxPgNuJIBdi8qli%2BWGXbEIwjQBxp1uqZxNWAEjYCSscrZbGncAeCEkloMHk%2B7S5boaNvATI0WOT8ccKWL456%2F3X835RQAFXdyWAAAAAElFTkSuQmCC";
    }),
    r("dbxPf", function (t, r) {
      e(t.exports, "default", () => i);
      var n = o("bfktz");
      o("gQnzB"), o("7gRhS");
      var a = o("bL6OX");
      function i({ item: e, onClose: t }) {
        let o;
        return (
          (o = e.properties.url
            ? (0, n.jsxs)("a", {
                href: e.properties.url,
                className: "link-with-smalls",
                children: [
                  (0, n.jsx)("div", {
                    className: "description",
                    children: e.properties.name,
                  }),
                  e.properties.services
                    ? (0, n.jsx)("div", {
                        className: "smalls",
                        children: e.properties.services.join("  "),
                      })
                    : null,
                ],
              })
            : (0, n.jsx)("div", { children: e.properties.name })),
          (0, n.jsx)(a.Popup, {
            offset: 2,
            latitude: e.geometry.coordinates[1],
            longitude: e.geometry.coordinates[0],
            closeOnClick: !1,
            onClose: t,
            focusAfterOpen: !1,
            children: o,
          })
        );
      }
    }),
    r("6R9wn", function (t, r) {
      e(t.exports, "getClickedVehicleMarkerId", () => l),
        e(t.exports, "default", () => s);
      var n = o("bfktz"),
        a = o("gQnzB");
      o("7gRhS");
      var i = o("7S46k");
      function l(e) {
        let t = e.originalEvent.target;
        if (t instanceof HTMLElement || t instanceof SVGElement) {
          let e = t.dataset.vehicleId;
          if (
            (!e && t.parentElement && (e = t.parentElement.dataset.vehicleId),
            !e &&
              (t.firstChild instanceof HTMLElement ||
                t.firstChild instanceof SVGElement) &&
              (e = t.firstChild.dataset.vehicleId),
            e)
          )
            return Number.parseInt(e, 10);
        }
      }
      var s = (0, a.memo)(
        function ({ vehicle: e, selected: t }) {
          var o, r, a, l, s;
          let u = "vehicle-marker",
            c = e.heading,
            d = "";
          (null === (o = e.vehicle) || void 0 === o ? void 0 : o.css) &&
            (d = e.vehicle.css),
            null != c &&
              (c < 180
                ? ((c -= 90),
                  (u += " right"),
                  (null === (s = e.vehicle) || void 0 === s
                    ? void 0
                    : s.right_css) && (d = e.vehicle.right_css))
                : (c -= 270));
          let p = null === (r = e.vehicle) || void 0 === r ? void 0 : r.livery;
          p
            ? (u += ` livery-${p}`)
            : d &&
              (null === (a = e.vehicle) || void 0 === a
                ? void 0
                : a.text_colour) &&
              (u += " white-text"),
            t && (u += " selected");
          let f =
            (null === (l = e.service) || void 0 === l ? void 0 : l.line_name) ||
            "";
          return (
            (f =
              p && 262 !== p && 1502 !== p
                ? (0, n.jsx)("svg", {
                    width: "24",
                    height: "16",
                    "data-vehicle-id": e.id,
                    className: u,
                    children: (0, n.jsx)("text", {
                      x: "12",
                      y: "12",
                      children: f,
                    }),
                  })
                : (0, n.jsx)("div", {
                    "data-vehicle-id": e.id,
                    className: u,
                    style: d ? { background: d } : void 0,
                    children: f,
                  })),
            (0, n.jsxs)(i.Marker, {
              latitude: e.coordinates[1],
              longitude: e.coordinates[0],
              rotation: c,
              style: { zIndex: +!!t },
              "data-vehicle-id": e.id,
              children: [
                f,
                null == c
                  ? null
                  : (0, n.jsx)("div", {
                      className: "arrow",
                      "data-vehicle-id": e.id,
                    }),
              ],
            })
          );
        },
        function (e, t) {
          return (
            e.selected === t.selected &&
            e.vehicle.datetime === t.vehicle.datetime
          );
        }
      );
    }),
    r("gptNO", function (t, r) {
      e(t.exports, "default", () => u);
      var n = o("bfktz");
      o("gQnzB"), o("7gRhS");
      var a = o("bL6OX"),
        i = o("7BBPl"),
        l = o("4GBmY");
      function s({ item: e }) {
        let t = e.delay;
        if (void 0 !== t) {
          let e;
          let o = Math.abs(t);
          return (
            o < 45
              ? (e = "On time")
              : ((e = t < 0 ? "early" : "late"),
                (e = `${(function (e) {
                  let t = Math.round(e / 60);
                  return 1 === t ? "1 minute" : `${t} minutes`;
                })(o)} ${e}`)),
            (0, n.jsx)("div", { children: e })
          );
        }
      }
      function u({
        item: e,
        onClose: t,
        snazzyTripLink: o = !1,
        activeLink: r = !1,
      }) {
        var u, c, d, p, f;
        let h =
          (null === (u = e.service) || void 0 === u ? void 0 : u.line_name) ||
          "";
        e.destination && (h && (h += " to "), (h += e.destination)),
          e.trip_id
            ? r ||
              (h = o
                ? (0, n.jsx)(l.Link, {
                    href: `/trips/${e.trip_id}`,
                    children: h,
                  })
                : (0, n.jsx)("a", { href: `/trips/${e.trip_id}`, children: h }))
            : e.journey_id
            ? r ||
              (h = o
                ? (0, n.jsx)(l.Link, {
                    href: `/journeys/${e.journey_id}`,
                    children: h,
                  })
                : (0, n.jsx)("a", {
                    href: `/journeys/${e.journey_id}`,
                    children: h,
                  }))
            : e.tfl_code
            ? (h = (0, n.jsx)("a", {
                href: `/vehicles/tfl/${e.tfl_code}`,
                children: h,
              }))
            : (null === (c = e.service) || void 0 === c ? void 0 : c.url) &&
              e.service.url !== window.location.pathname &&
              (h = (0, n.jsx)("a", { href: e.service.url, children: h }));
        let m = null === (d = e.vehicle) || void 0 === d ? void 0 : d.name;
        return (
          (null === (p = e.vehicle) || void 0 === p ? void 0 : p.url) &&
            (m = (0, n.jsx)("a", { href: `${e.vehicle.url}`, children: m })),
          (0, n.jsxs)(a.Popup, {
            offset: 8,
            latitude: e.coordinates[1],
            longitude: e.coordinates[0],
            closeOnClick: !1,
            onClose: t,
            focusAfterOpen: !1,
            children: [
              (0, n.jsx)("div", { children: h }),
              m,
              (null === (f = e.vehicle) || void 0 === f
                ? void 0
                : f.features) &&
                (0, n.jsx)("div", {
                  children: e.vehicle.features.replace("<br>", ", "),
                }),
              e.seats &&
                (0, n.jsxs)("div", {
                  children: [
                    (0, n.jsxs)("svg", {
                      role: "img",
                      width: "14",
                      height: "14",
                      viewBox: "0 0 118 177",
                      xmlns: "http://www.w3.org/2000/svg",
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeMiterlimit: "1.5",
                      children: [
                        (0, n.jsx)("title", { children: "Seats" }),
                        (0, n.jsx)("path", {
                          d: "M108 9l-19 99-80-1 48 1v59",
                          fill: "none",
                          stroke: "currentColor",
                          strokeWidth: "18",
                        }),
                      ],
                    }),
                    " ",
                    e.seats,
                  ],
                }),
              e.wheelchair &&
                (0, n.jsxs)("div", {
                  children: [
                    (0, n.jsxs)("svg", {
                      role: "img",
                      width: "14",
                      height: "14",
                      viewBox: "0 0 506 647",
                      xmlns: "http://www.w3.org/2000/svg",
                      strokeLinejoin: "round",
                      strokeMiterlimit: "2",
                      children: [
                        (0, n.jsx)("title", { children: "Wheelchair space" }),
                        (0, n.jsx)("path", {
                          fill: "currentColor",
                          d: "M494.28 293.25a38.5 38.5 0 00-29.66-11.55l-133.98 7.46 73.74-83.97a45.03 45.03 0 009.44-42.16 38.26 38.26 0 00-17.14-24.32c-.28-.2-176.25-102.43-176.25-102.43a38.42 38.42 0 00-44.87 4.56L89.6 117.5a38.43 38.43 0 1051.16 57.35l65.17-58.13 53.87 31.29-95.1 108.3a195.94 195.94 0 00-102.76 50.8l49.66 49.66a125.86 125.86 0 0184.92-32.87c69.66 0 126.34 56.68 126.34 126.35 0 32.66-12.46 62.47-32.87 84.92l49.66 49.65a195.76 195.76 0 0053.38-134.57c0-31.04-7.2-60.39-20.01-86.48l51.86-2.9-12.62 154.76a38.43 38.43 0 0076.6 6.24l16.2-198.68a38.42 38.42 0 00-10.78-29.95zM423.1 128.65A64.32 64.32 0 10423.1 0a64.32 64.32 0 000 128.65zM196.52 576.6c-69.67 0-126.35-56.67-126.35-126.34 0-26.26 8.06-50.66 21.82-70.89l-50.2-50.2A195.62 195.62 0 000 450.27c0 108.53 87.98 196.51 196.52 196.51 45.69 0 87.7-15.63 121.08-41.79l-50.2-50.19a125.64 125.64 0 01-70.88 21.82z",
                        }),
                      ],
                    }),
                    " ",
                    e.wheelchair,
                  ],
                }),
              (0, n.jsx)(s, { item: e }),
              (0, n.jsx)("div", {
                children: (0, n.jsx)(
                  i.default,
                  { date: e.datetime },
                  e.datetime
                ),
              }),
            ],
          })
        );
      }
    }),
    r("7BBPl", function (t, r) {
      e(t.exports, "default", () => u);
      var n = o("gQnzB"),
        a = o("QfAbz"),
        i = o("bxIGA");
      function l() {
        return (l = Object.assign
          ? Object.assign.bind()
          : function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var o = arguments[t];
                for (var r in o)
                  Object.prototype.hasOwnProperty.call(o, r) && (e[r] = o[r]);
              }
              return e;
            }).apply(this, arguments);
      }
      let s = () => Date.now();
      function u({
        date: e,
        formatter: t = i.default,
        component: o = "time",
        live: r = !0,
        minPeriod: u = 0,
        maxPeriod: c = 604800,
        title: d,
        now: p = s,
        ...f
      }) {
        let [h, m] = (0, n.useState)(p());
        (0, n.useEffect)(() => {
          if (!r) return;
          let t = (() => {
            let t = (0, a.default)(e).valueOf();
            if (!t)
              return console.warn("[react-timeago] Invalid Date provided"), 0;
            let o = Math.round(Math.abs(h - t) / 1e3),
              r = Math.min(
                Math.max(
                  o < 60 ? 1e3 : o < 3600 ? 6e4 : o < 86400 ? 36e5 : 6048e5,
                  1e3 * u
                ),
                1e3 * c
              );
            return r
              ? setTimeout(() => {
                  m(p());
                }, r)
              : 0;
          })();
          return () => {
            t && clearTimeout(t);
          };
        }, [e, r, c, u, p, h]);
        let g = (0, a.default)(e).valueOf();
        if (!g) return null;
        let v = Math.round(Math.abs(h - g) / 1e3),
          y = g < h ? "ago" : "from now",
          [A, x] =
            v < 60
              ? [Math.round(v), "second"]
              : v < 3600
              ? [Math.round(v / 60), "minute"]
              : v < 86400
              ? [Math.round(v / 3600), "hour"]
              : v < 604800
              ? [Math.round(v / 86400), "day"]
              : v < 2592e3
              ? [Math.round(v / 604800), "week"]
              : v < 31536e3
              ? [Math.round(v / 2592e3), "month"]
              : [Math.round(v / 31536e3), "year"],
          C =
            void 0 === d
              ? "string" == typeof e
                ? e
                : (0, a.default)(e)
                    .toISOString()
                    .substr(0, 16)
                    .replace("T", " ")
              : d,
          E =
            "time" === o
              ? { ...f, dateTime: (0, a.default)(e).toISOString() }
              : f,
          S = (0, i.default).bind(null, A, x, y);
        return n.createElement(o, l({}, E, { title: C }), t(A, x, y, g, S, p));
      }
    }),
    r("QfAbz", function (t, o) {
      e(t.exports, "default", () => r);
      function r(e) {
        let t = new Date(e);
        if (!Number.isNaN(t.valueOf())) return t;
        let o = String(e).match(/\d+/g);
        if (null == o || o.length <= 2) return t;
        {
          let [e, t, ...r] = o.map((e) => parseInt(e));
          return new Date(Date.UTC(e, t - 1, ...r));
        }
      }
    }),
    r("bxIGA", function (t, o) {
      e(t.exports, "default", () => r);
      function r(e, t, o) {
        return e + " " + (1 !== e ? t + "s" : t) + " " + o;
      }
    }),
    r("4GBmY", function (t, r) {
      e(t.exports, "Route", () => b),
        e(t.exports, "Link", () => w),
        e(t.exports, "Switch", () => L);
      var n = o("3Vj9T"),
        a = o("dnrrQ");
      o("1byFf");
      var i = o("gQnzB"),
        l = o("1byFf");
      let s = (e, t) =>
          t.toLowerCase().indexOf(e.toLowerCase())
            ? "~" + t
            : t.slice(e.length) || "/",
        u = (e = "") => ("/" === e ? "" : e),
        c = (e, t) => ("~" === e[0] ? e.slice(1) : u(t) + e),
        d = (e = "", t) => s(p(u(e)), p(t)),
        p = (e) => {
          try {
            return decodeURI(e);
          } catch (t) {
            return e;
          }
        },
        f = {
          hook: a.useBrowserLocation,
          searchHook: a.useSearch,
          parser: n.parse,
          base: "",
          ssrPath: void 0,
          ssrSearch: void 0,
          ssrContext: void 0,
          hrefs: (e) => e,
        },
        h = (0, i.createContext)(f),
        m = () => (0, i.useContext)(h),
        g = {},
        v = (0, i.createContext)(g),
        y = () => (0, i.useContext)(v),
        A = (e) => {
          let [t, o] = e.hook(e);
          return [d(e.base, t), (0, l.useEvent)((t, r) => o(c(t, e.base), r))];
        },
        x = (e, t, o, r) => {
          let { pattern: n, keys: a } =
              t instanceof RegExp ? { keys: !1, pattern: t } : e(t || "*", r),
            i = n.exec(o) || [],
            [l, ...s] = i;
          return void 0 !== l
            ? [
                !0,
                (() => {
                  let e =
                      !1 !== a
                        ? Object.fromEntries(a.map((e, t) => [e, s[t]]))
                        : i.groups,
                    t = { ...s };
                  return e && Object.assign(t, e), t;
                })(),
                ...(r ? [l] : []),
              ]
            : [!1, null];
        },
        C = ({ children: e, ...t }) => {
          var o, r, n, a;
          let l = m(),
            s = t.hook ? f : l,
            u = s,
            [c, d] =
              null !==
                (n =
                  null === (o = t.ssrPath) || void 0 === o
                    ? void 0
                    : o.split("?")) && void 0 !== n
                ? n
                : [];
          d && ((t.ssrSearch = d), (t.ssrPath = c)),
            (t.hrefs =
              null !== (a = t.hrefs) && void 0 !== a
                ? a
                : null === (r = t.hook) || void 0 === r
                ? void 0
                : r.hrefs);
          let p = (0, i.useRef)({}),
            g = p.current,
            v = g;
          for (let e in s) {
            let o = "base" === e ? s[e] + (t[e] || "") : t[e] || s[e];
            g === v && o !== v[e] && (p.current = v = { ...v }),
              (v[e] = o),
              o !== s[e] && (u = v);
          }
          return (0, i.createElement)(h.Provider, { value: u, children: e });
        },
        E = ({ children: e, component: t }, o) =>
          t
            ? (0, i.createElement)(t, { params: o })
            : "function" == typeof e
            ? e(o)
            : e,
        S = (e) => {
          let t = (0, i.useRef)(g),
            o = t.current;
          return (t.current =
            Object.keys(e).length !== Object.keys(o).length ||
            Object.entries(e).some(([e, t]) => t !== o[e])
              ? e
              : o);
        },
        b = ({ path: e, nest: t, match: o, ...r }) => {
          let n = m(),
            [a] = A(n),
            [l, s, u] = null != o ? o : x(n.parser, e, a, t),
            c = S({ ...y(), ...s });
          if (!l) return null;
          let d = u ? (0, i.createElement)(C, { base: u }, E(r, c)) : E(r, c);
          return (0, i.createElement)(v.Provider, { value: c, children: d });
        },
        w = (0, i.forwardRef)((e, t) => {
          let o = m(),
            [r, n] = A(o),
            {
              to: a = "",
              href: s = a,
              onClick: u,
              asChild: c,
              children: d,
              className: p,
              replace: f,
              state: h,
              ...g
            } = e,
            v = (0, l.useEvent)((t) => {
              t.ctrlKey ||
                t.metaKey ||
                t.altKey ||
                t.shiftKey ||
                0 !== t.button ||
                (null == u || u(t),
                t.defaultPrevented || (t.preventDefault(), n(s, e)));
            }),
            y = o.hrefs("~" === s[0] ? s.slice(1) : o.base + s, o);
          return c && (0, i.isValidElement)(d)
            ? (0, i.cloneElement)(d, { onClick: v, href: y })
            : (0, i.createElement)("a", {
                ...g,
                onClick: v,
                href: y,
                className: (null == p ? void 0 : p.call) ? p(r === s) : p,
                children: d,
                ref: t,
              });
        }),
        B = (e) =>
          Array.isArray(e)
            ? e.flatMap((e) =>
                B(e && e.type === i.Fragment ? e.props.children : e)
              )
            : [e],
        L = ({ children: e, location: t }) => {
          let o = m(),
            [r] = A(o);
          for (let n of B(e)) {
            let e = 0;
            if (
              (0, i.isValidElement)(n) &&
              (e = x(o.parser, n.props.path, t || r, n.props.nest))[0]
            )
              return (0, i.cloneElement)(n, { match: e });
          }
          return null;
        };
    }),
    r("3Vj9T", function (t, o) {
      e(t.exports, "parse", () => r);
      function r(e, t) {
        if (e instanceof RegExp) return { keys: !1, pattern: e };
        var o,
          r,
          n,
          a,
          i = [],
          l = "",
          s = e.split("/");
        for (s[0] || s.shift(); (n = s.shift()); )
          "*" === (o = n[0])
            ? (i.push(o), (l += "?" === n[1] ? "(?:/(.*))?" : "/(.*)"))
            : ":" === o
            ? ((r = n.indexOf("?", 1)),
              (a = n.indexOf(".", 1)),
              i.push(n.substring(1, ~r ? r : ~a ? a : n.length)),
              (l += ~r && !~a ? "(?:/([^/]+?))?" : "/([^/]+?)"),
              ~a && (l += (~r ? "?" : "") + "\\" + n.substring(a)))
            : (l += "/" + n);
        return {
          keys: i,
          pattern: RegExp("^" + l + (t ? "(?=$|/)" : "/?$"), "i"),
        };
      }
    }),
    r("dnrrQ", function (t, r) {
      e(t.exports, "useSearch", () => d),
        e(t.exports, "useBrowserLocation", () => m),
        o("1byFf");
      var n = o("g7fom");
      let a = "pushState",
        i = "replaceState",
        l = ["popstate", a, i, "hashchange"],
        s = (e) => {
          for (let t of l) addEventListener(t, e);
          return () => {
            for (let t of l) removeEventListener(t, e);
          };
        },
        u = (e, t) => (0, n.useSyncExternalStore)(s, e, t),
        c = () => location.search,
        d = ({ ssrSearch: e = "" } = {}) => u(c, () => e),
        p = () => location.pathname,
        f = ({ ssrPath: e } = {}) => u(p, e ? () => e : p),
        h = (e, { replace: t = !1, state: o = null } = {}) =>
          history[t ? i : a](o, "", e),
        m = (e = {}) => [f(e), h],
        g = Symbol.for("wouter_v3");
      if ("undefined" != typeof history && void 0 === window[g]) {
        for (let e of [a, i]) {
          let t = history[e];
          history[e] = function () {
            let o = t.apply(this, arguments),
              r = new Event(e);
            return (r.arguments = arguments), dispatchEvent(r), o;
          };
        }
        Object.defineProperty(window, g, { value: !0 });
      }
    }),
    r("1byFf", function (t, r) {
      e(t.exports, "useIsomorphicLayoutEffect", () => i),
        e(t.exports, "useEvent", () => s),
        e(t.exports, "Fragment", () => o("gQnzB").Fragment),
        e(t.exports, "cloneElement", () => o("gQnzB").cloneElement),
        e(t.exports, "createContext", () => o("gQnzB").createContext),
        e(t.exports, "createElement", () => o("gQnzB").createElement),
        e(t.exports, "forwardRef", () => o("gQnzB").forwardRef),
        e(t.exports, "isValidElement", () => o("gQnzB").isValidElement),
        e(t.exports, "useContext", () => o("gQnzB").useContext),
        e(t.exports, "useMemo", () => o("gQnzB").useMemo),
        e(t.exports, "useRef", () => o("gQnzB").useRef),
        e(
          t.exports,
          "useSyncExternalStore",
          () => o("g7fom").useSyncExternalStore
        );
      var n = o("gQnzB");
      o("g7fom");
      let a = n.useInsertionEffect,
        i =
          "undefined" != typeof window &&
          void 0 !== window.document &&
          void 0 !== window.document.createElement
            ? n.useLayoutEffect
            : n.useEffect,
        l = a || i,
        s = (e) => {
          let t = n.useRef([e, (...e) => t[0](...e)]).current;
          return (
            l(() => {
              t[0] = e;
            }),
            t[1]
          );
        };
    }),
    r("g7fom", function (e, t) {
      e.exports = o("aPZmv");
    }),
    r("aPZmv", function (t, r) {
      e(
        t.exports,
        "useSyncExternalStore",
        () => n,
        (e) => (n = e)
      );
      var n,
        a = o("gQnzB"),
        i =
          "function" == typeof Object.is
            ? Object.is
            : function (e, t) {
                return (
                  (e === t && (0 !== e || 1 / e == 1 / t)) || (e != e && t != t)
                );
              },
        l = a.useState,
        s = a.useEffect,
        u = a.useLayoutEffect,
        c = a.useDebugValue;
      function d(e) {
        var t = e.getSnapshot;
        e = e.value;
        try {
          var o = t();
          return !i(e, o);
        } catch (e) {
          return !0;
        }
      }
      var p =
        "undefined" == typeof window ||
        void 0 === window.document ||
        void 0 === window.document.createElement
          ? function (e, t) {
              return t();
            }
          : function (e, t) {
              var o = t(),
                r = l({ inst: { value: o, getSnapshot: t } }),
                n = r[0].inst,
                a = r[1];
              return (
                u(
                  function () {
                    (n.value = o), (n.getSnapshot = t), d(n) && a({ inst: n });
                  },
                  [e, o, t]
                ),
                s(
                  function () {
                    return (
                      d(n) && a({ inst: n }),
                      e(function () {
                        d(n) && a({ inst: n });
                      })
                    );
                  },
                  [e]
                ),
                c(o),
                o
              );
            };
      n = void 0 !== a.useSyncExternalStore ? a.useSyncExternalStore : p;
    });
})();
//# sourceMappingURL=ServiceMapMap.a5926f6a.js.1a060ef72d8a.map
